# Govt. Holkar Science College Indore - Android App Project

This is the ready-to-build Android Studio project for Govt. Model Autonomous Holkar Science College, Indore.

## How to Build the Debug APK (`app-debug.apk`):

### Option 1: Using Android Studio (Recommended)
1. Open Android Studio.
2. Select **File > Open...** and choose this unzipped project folder.
3. Wait for Gradle Sync to complete.
4. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Once completed, click **locate** to find `app-debug.apk` in `app/build/outputs/apk/debug/`.
6. Transfer `app-debug.apk` to any Android phone and install!

### Option 2: Using Command Line (Gradle)
Run in the project directory:
```bash
./gradlew assembleDebug
```
On Windows:
```cmd
gradlew.bat assembleDebug
```
The output APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

---
### Android App Features:
- **Fast Native WebView**: Hardware accelerated, local storage persistent.
- **Pull to Refresh**: Swipe down anywhere to reload live updates and notices.
- **Camera & File Chooser**: Supports photo and document uploads for examination forms and grievances.
- **Deep Linking**: Direct handling of telephone, email, and location intents.
- **Status & Navigation Bar**: Styled in college navy `#020617` with light icons.
