@echo off
setlocal

:: Try to find Java from Android Studio or standard JDK paths if JAVA_HOME is not set
if not defined JAVA_HOME (
    if exist "C:\Program Files\Android\Android Studio\jbr\bin\java.exe" (
        set "JAVA_HOME=C:\Program Files\Android\Android Studio\jbr"
    ) else if exist "C:\Program Files\Android\Android Studio\jre\bin\java.exe" (
        set "JAVA_HOME=C:\Program Files\Android\Android Studio\jre"
    ) else if exist "%LOCALAPPDATA%\Programs\Android Studio\jbr\bin\java.exe" (
        set "JAVA_HOME=%LOCALAPPDATA%\Programs\Android Studio\jbr"
    ) else if exist "C:\Program Files\Java\jdk-17\bin\java.exe" (
        set "JAVA_HOME=C:\Program Files\Java\jdk-17"
    )
)

if defined JAVA_HOME (
    set "PATH=%JAVA_HOME%\bin;%PATH%"
    echo Using Java from: %JAVA_HOME%
)

echo ========================================================
echo Building Holkar Science College Android APK (Debug)...
echo ========================================================
call gradlew.bat assembleDebug
if %ERRORLEVEL% EQU 0 (
    echo.
    echo ========================================================
    echo SUCCESS: APK Generated Successfully!
    echo Location: app\build\outputs\apk\debug\app-debug.apk
    echo ========================================================
    if exist "app\build\outputs\apk\debug\app-debug.apk" (
        explorer /select,"app\build\outputs\apk\debug\app-debug.apk"
    )
) else (
    echo.
    echo BUILD FAILED. Make sure you have an internet connection and JDK 17.
)
pause
